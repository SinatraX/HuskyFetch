﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml.Serialization;

using HuskyFetchObjects.Objects.BaseObjects;

namespace HuskyFetchObjects
{
    // LevelManagerLoadTypes is responsible for loading the xml file based on when you start the game, complete a level, or lose lives and reset the level.
    public enum LevelManagerLoadTypes
    {
        STARTUP,    // Loads the first level when you run HuskyFetchObjects
        FIRST,      // Loads the first level when you are out of lives
        NEXT,       // Loads the next level after completion of previous.
        RELOAD      // Loads the current level after leaving game.
    };

    public class LevelManager
    {
        #region Singleton

        private static LevelManager instance;
        public static LevelManager Instance
        {
            get
            {
                if(instance == null) { instance = new LevelManager(); }
                return instance;
            }
        }

        #endregion
        
        public int CurrentLevelIndex { get; set; }
        public int HuskyLives { get; set; }
        public List<string> LevelFilePaths { get; set; }

        public string CurrentLevelName
        {
            get { return LevelFilePaths[CurrentLevelIndex]; }
        }

        public LevelManager()
        {
            CurrentLevelIndex = 0;
            HuskyLives = 5;
            LevelFilePaths = new List<string>();
        }

        // InLevelManager establishes xml serialization/deserialization of design files 
        public void InLevelManager(string filepath)
        {
            StreamReader streamReader = new StreamReader(filepath);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(LevelManager));
            LevelManager tmpManager = (LevelManager)xmlSerializer.Deserialize(streamReader);
            this.CurrentLevelIndex = tmpManager.CurrentLevelIndex;
            this.HuskyLives = tmpManager.HuskyLives;
            this.LevelFilePaths = tmpManager.LevelFilePaths;
            streamReader.Close();
        }

        // Intended to save the game properties
        public void SaveLevelManager(string filepath)
        {
            StreamWriter streamWriter = new StreamWriter(filepath);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(LevelManager));
            xmlSerializer.Serialize(streamWriter, this);
            streamWriter.Close();
        }

        // Load the levels
        public Level LoadLevel(LevelManagerLoadTypes levelLoadType)
        {
            // If no .xml files are in the correct file path.
            // Levels designed are saved as .xml
            if (LevelFilePaths.Count == 0)
            {
                MessageBox.Show("No levels are configured in the levels file.", "No levels configured.", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }

            switch(levelLoadType)
            {
                // Remember first is for first level
                case LevelManagerLoadTypes.FIRST:
                {
                    CurrentLevelIndex = 0;
                    break;
                }
                // Remember next is for moving onto next level
                case LevelManagerLoadTypes.NEXT:
                {
                    CurrentLevelIndex++;
                    if (CurrentLevelIndex < 0) { CurrentLevelIndex = 0; }
                    if (CurrentLevelIndex >= LevelFilePaths.Count)
                    {
                        CurrentLevelIndex = LevelFilePaths.Count - 1;
                        // If statement once final level is done.
                        if(MessageBox.Show("Congratulations! You have completed the game! Would you like to play again? (Yes)? Otherwise the current level is repeated.", "Highest level reached.", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            CurrentLevelIndex = 0;
                        }
                    }
                    break;
                }
                case LevelManagerLoadTypes.STARTUP:
                case LevelManagerLoadTypes.RELOAD:
                {
                    if (CurrentLevelIndex < 0) { CurrentLevelIndex = 0; }
                    if (CurrentLevelIndex >= LevelFilePaths.Count) { CurrentLevelIndex = LevelFilePaths.Count - 1; }
                    break;
                }
            }

            if(levelLoadType == LevelManagerLoadTypes.RELOAD)
            {
                HuskyLives--;
                // Restarts the game if out of lives.
                if(HuskyLives == 0)
                {
                    MessageBox.Show("Oh no, your husky is out of lives! Now you have to start oveer.", "Game Over.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CurrentLevelIndex = 0;
                    HuskyLives = 5;
                }
            }

            return HuskyEditorXML.LoadLevelFromXML(LevelFilePaths[CurrentLevelIndex]);
        }

    }
}
