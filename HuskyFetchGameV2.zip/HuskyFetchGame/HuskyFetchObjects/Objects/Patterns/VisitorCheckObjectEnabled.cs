﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;

namespace HuskyFetchObjects.Objects.Patterns
{
    // ref for level and graphobj
    public class VisitorCheckObjectEnabled : VisitorObject
    {
        public override void Action(GraphicObject g)
        {
            base.Action(g);

            g.CheckObjectEnabled();

        }
    }
}
