﻿// This file is intended to generate all images used for Husky Fetch
using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.IO;

namespace HuskyFetchObjects.Objects.Utils
{
    public class ImageGenerator
    {
        public Bitmap Block;
        public Bitmap Grass;
        public Bitmap Bone;
        public Bitmap Food;
        public Bitmap Background;
        public Bitmap Grant;
        public Bitmap Suri;
        public Bitmap Goda;
        public Bitmap PipeUp;
        public Bitmap HuskySmall;
        public Bitmap HuskyBig;
        public Bitmap HuskyFire;
        public Bitmap FireBall;
        public Bitmap Mush;
        public Bitmap Flower;
        public Bitmap Brick;
        public Bitmap BrickPiece;
        public Bitmap MovingPlatform;
        public Bitmap SolidPlatform;
        public Bitmap FinishDoor;

        private static ImageGenerator instance = null;


        private ImageGenerator()
        {
            // variable strNameSpace is intended to automatically pick up the Namespace of HuskyFetchObjects. Helpful for redundancy
            string strNameSpace =
            System.Reflection.Assembly.GetExecutingAssembly().GetName().Name.ToString();

            // The following up until Line 111 is the code for generating the images we have in the Images folder
            Stream str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Blocks.itemblock.png");
            Block = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Blocks.brick.png");
            Brick = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Blocks.brickpiece.png");
            BrickPiece = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Blocks.grass.png");
            Grass = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Blocks.pipeup.png");
            PipeUp = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Blocks.movingblock.png");
            MovingPlatform = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Blocks.solidblock.png");
            SolidPlatform = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Blocks.exit.png");
            FinishDoor = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Items.bone.png");
            Bone = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Items.dogeater.png");
            Food = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Items.mush.png");
            Mush = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Items.fireflower.png");
            Flower = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Backgrounds.bgblock.png");
            Background = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Monsters.professorgrant.png");
            Grant = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Monsters.professorsuri.png");
            Suri = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Monsters.professorgoda.png");
            Goda = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Husky.huskysmall.png");
            HuskySmall = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Husky.huskybig.png");
            HuskyBig = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Husky.huskyfire.png");
            HuskyFire = new Bitmap(str);

            str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + "Images.Husky.fireball.png");
            FireBall = new Bitmap(str);

        }
        // Method GetImage takes the images of the objects and is supposed to generate them
        public static Bitmap GetImage(ObjectType Type)
        {
            if (instance == null)
                instance = new ImageGenerator();

            switch (Type)
            {
                case ObjectType.OT_BrickQuestion:
                    return instance.Block;
                case ObjectType.OT_BrickQuestionHidden:
                    return instance.Block;
                case ObjectType.OT_Grass:
                    return instance.Grass;
                case ObjectType.OT_Bone:
                    return instance.Bone;
                case ObjectType.OT_Food:
                    return instance.Food;
                case ObjectType.OT_Background:
                    return instance.Background;
                case ObjectType.OT_Grant:
                    return instance.Grant;
                case ObjectType.OT_Pipe:
                    return instance.PipeUp;
                case ObjectType.OT_Husky:
                    return instance.HuskySmall;
                case ObjectType.OT_HuskySmall:
                    return instance.HuskySmall;
                case ObjectType.OT_HuskyBig:
                    return instance.HuskyBig;
                case ObjectType.OT_HuskyFire:
                    return instance.HuskyFire;
                case ObjectType.OT_FireBall:
                    return instance.FireBall;
                case ObjectType.OT_RedMushroom:
                    return instance.Mush;
                case ObjectType.OT_GreenMushroom:
                    return instance.Mush;
                case ObjectType.OT_Flower:
                    return instance.Flower;
                case ObjectType.OT_Brick:
                    return instance.Brick;
                case ObjectType.OT_BrickPiece:
                    return instance.BrickPiece;
                case ObjectType.OT_Suri:
                    return instance.Suri;
                case ObjectType.OT_Goda:
                    return instance.Goda;
                case ObjectType.OT_MovingPlatform:
                    return instance.MovingPlatform;
                case ObjectType.OT_SolidPlatform:
                    return instance.SolidPlatform;
                case ObjectType.OT_FinishDoor:
                    return instance.FinishDoor;
            }

            return null;
        }
    }
}
