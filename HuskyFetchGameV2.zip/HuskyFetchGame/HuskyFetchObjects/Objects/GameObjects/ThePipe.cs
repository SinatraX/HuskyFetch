﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class ThePipe : StaticGraphicObject
    {
        // Goda will be coming out of the purple pipe
        public ProfessorGoda Monster;

        public static LevelEditorObject GetLEObject()
        {
            // For the designers to select options of what comes out of the pipe
            return new LevelEditorObject(32, 32, 1, 0, ObjectType.OT_Pipe, new object[] { new object[] { new object[] { "Goda Fish", (int)(ProfessorGoda.GodaType.GT_Regular), "Goda Fire", (int)(ProfessorGoda.GodaType.GT_Fire), "None", (int)(ProfessorGoda.GodaType.GT_None) } }, 0 });
        }

        public static ThePipe SetLEObject(LevelEditorObject le)
        {
            return new ThePipe(le.x, le.y, (ProfessorGoda.GodaType)le.ParamInt[0]);
        }

        public override void Draw()
        {
            base.Draw();
        }
        // Method ThePipe will add the ProfessorGoda object
        public ThePipe(int x, int y, ProfessorGoda.GodaType T)
        {
            if (T != ProfessorGoda.GodaType.GT_None)
            {
                Monster = new ProfessorGoda(x, y, T);
                AddObject(Monster);
            }

            this.x = x;
            this.y = y;
            OT = ObjectType.OT_Pipe;
            SetWidthHeight();
        }
    }

}
