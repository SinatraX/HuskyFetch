﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class Brick : AnimatedGraphicObject
    {
        public MiniBrickPieces TopRight;
        public MiniBrickPieces TopLeft;
        public MiniBrickPieces ButtomRight;
        public MiniBrickPieces ButtomLeft;

        public static LevelEditorObject GetLEObject()
        {
            // Sets object's properties for designing
            return new LevelEditorObject(16, 16, 4, 0, ObjectType.OT_Brick, null);
        }
        public static Brick SetLEObject(LevelEditorObject le)
        {
            return new Brick(le.x, le.y);
        }


        // BreakBrick will be used for when the Husky is in its large state
        // or when Suri object runs into it in shield state
        public void BreakBrick()
        {
            Visible = false;
            Animated = false;

            TopRight.Running = true;
            TopLeft.Running = true;
            ButtomRight.Running = true;
            ButtomLeft.Running = true;


        }

        // Object animations
        public override void OnAnimate(object sender, EventArgs e)
        {
            base.OnAnimate(sender, e);
        }
        public override void Draw()
        {
            base.Draw();
        }
        
        // public Brick
        public Brick(int x, int y)
            : base(ObjectType.OT_Brick)
        {
            AnimatedCount = 4;
            this.x = x;
            this.y = y;
            SetWidthHeight();

            TopRight = new MiniBrickPieces(x, y, -30, 1);
            TopLeft = new MiniBrickPieces(x, y, -30, -1);
            ButtomRight = new MiniBrickPieces(x, y, -15, 1);
            ButtomLeft = new MiniBrickPieces(x, y, -15, -1);

            AddObject(TopRight);
            AddObject(TopLeft);
            AddObject(ButtomRight);
            AddObject(ButtomLeft);

            TimerGenerator.AddTimerEventHandler(TimerType.TT_100, OnAnimate);
        }
    }


}
