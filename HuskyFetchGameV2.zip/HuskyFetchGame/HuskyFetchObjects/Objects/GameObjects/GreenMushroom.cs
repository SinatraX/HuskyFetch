﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class GreenMushroom : MoveableAnimatedObject
    {
        public override void OnWalk(object sender, EventArgs e)
        {
            if (Live)
                base.OnWalk(sender, e);
        }

        // Method GreenMushroom properties
        // Goal is to make sure that when the Husky interacts
        // with this the amount of lives the user has increases
        public GreenMushroom(int x, int y)
            : base(ObjectType.OT_GreenMushroom)
        {
            ImageCount = 2;
            ImageIndex = 1;
            this.x = x;
            this.y = y;
            WalkStep = 2;
            SetWidthHeight();
            Live = false;
            Visible = false;

            TimerGenerator.AddTimerEventHandler(TimerType.TT_50, OnWalk);
        }
    }

   
}
