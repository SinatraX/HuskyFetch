﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class ProfessorGoda : AnimatedGraphicObject
    {
        public enum GodaType { GT_None, GT_Regular, GT_Fire }
        public enum GodaDirection { GD_Right, GD_Left };
        public enum GodaMovement { GM_None, GM_Up, GN_Middle, GM_Down };
        public GodaType Type;
        public GodaDirection Direction;
        public GodaMovement Move;

        public int OffY;
        public Boolean Live;
        public FireBall Ball;
        public Boolean FireOnce = false;


        // Method Intersection contains a series of code for how
        // Goda will interact with Husky
        public override void Intersection(Collision c, GraphicObject g)
    {
        base.Intersection(c, g);

        switch (g.OT)
        {
            case ObjectType.OT_Husky:
            {
                // Handle collision with Husky
                if (Move != GodaMovement.GM_None) // For when Goda is out of pipe
                {
                    if (c.Dir != CollisionDirection.CD_Down)
                    {
                        Husky h = (Husky)g;
                        if (!h.Blinking)
                        {
                            h.HuskyHandleCollision();
                        }
                    }
                }
                break;
            }
        }
    }

    public void SetDirection()
        {
            if (newx >= LevelGenerator.CurrentLevel.HuskyObject.x)
                Direction = GodaDirection.GD_Left;
            else
                Direction = GodaDirection.GD_Right;

            SetGodaProperties();

        }
        
        // OnAnimate contains animations for what Goda will look like if Husky crushes Goda
        public override void OnAnimate(object sender, EventArgs e)
        {
            base.OnAnimate(sender, e);
        }
        
        // OnMove is intended for what Goda will do when it's out of the pipe.
        // This is based on the criteria that the pipe puts out a specific GodaType
        public void OnMove(object sender, EventArgs e)
        {
            if (Live == false)
                return;

            if (Move == GodaMovement.GM_Up)
            {
                if (Type == GodaType.GT_Fire)
                    Animated = false;
                else
                    Animated = true;

                OffY += 1;
                newy -= 1;

                if (OffY >= height)
                {
                    Move = GodaMovement.GN_Middle;
                    OffY = 0;
                }

            }
            else
                if (Move == GodaMovement.GM_Down)
                {
                    if (Type == GodaType.GT_Fire)
                    {
                        Animated = false;
                        if (!Ball.Started)
                        {
                            UpdateOffsetsFireBall();
                            if (FireOnce)
                            {
                                Ball.RunFireBall(newx, newy, FireBall.FireBallType.FT_Goda, FireBall.FireBallDir.FB_Left);
                                FireOnce = false;
                            }
                        }
                    }
                    else
                        Animated = true;


                    OffY += 1;
                    newy += 1;

                    if (OffY >= height)
                    {
                        Move = GodaMovement.GM_None;
                        OffY = 0;
                    }

                }
                else if (Move == GodaMovement.GN_Middle)
                {
                    Animated = true;


                    OffY += 1;

                    if (OffY >= height)
                    {
                        Move = GodaMovement.GM_Down;
                        FireOnce = true;
                        OffY = 0;
                    }

                }
                else
                {
                    OffY += 1;

                    if (OffY >= height * 2)
                    {
                        Move = GodaMovement.GM_Up;
                        OffY = 0;
                        SetDirection();
                    }
                }
        }
        public void UpdateOffsetsFireBall()
        {
            double srcy, desty;
            double dx = 5;
            double dy;
            int absx = Math.Abs(newx - LevelGenerator.CurrentLevel.HuskyObject.x) / (int)dx;
            srcy = LevelGenerator.CurrentLevel.HuskyObject.y;
            desty = newy - height;

            dy = (srcy - desty) / absx;

            if (newx > LevelGenerator.CurrentLevel.HuskyObject.x)
                dx *= -1;

            Ball.SetOffXY(dx, dy);
        }

        // For when the Husky stomps on Goda
        public void HuskyGodaDie()
        {
            newy = LevelGenerator.LevelHeight;
            Animated = false;
            Live = false;
        }

        public override void Draw()
        {
            base.Draw();
        }

        // SetGodaProperties sets the properties of the various professorgoda's when it comes out of the pipe
        public void SetGodaProperties()
        {
            switch (Type)
            {
                case GodaType.GT_Regular:
                    {
                        AnimatedCount = 2;
                        OffsetIndex = 8;
                    } break;
                case GodaType.GT_Fire:
                    {

                        if (Direction == GodaDirection.GD_Left)
                        {
                            AnimatedCount = 4;
                            OffsetIndex = 0;
                        }
                        if (Direction == GodaDirection.GD_Right)
                        {
                            AnimatedCount = 4;
                            OffsetIndex = 4;
                        }

                    } break;
            }
        }
        public ProfessorGoda(int x, int y, GodaType T)
            : base(ObjectType.OT_Goda)
        {
            ImageCount = 10;

            Type = T;
            SetGodaProperties();
            Move = GodaMovement.GM_None;

            this.x = x;
            this.y = y;
            SetWidthHeight();
            newx += 8;
            width = 16;
            OffY = 0;
            Live = true;

            Ball = new FireBall(0, 0);
            AddObject(Ball);

            TimerGenerator.AddTimerEventHandler(TimerType.TT_500, OnAnimate);
            TimerGenerator.AddTimerEventHandler(TimerType.TT_50, OnMove);

        }
    }

}
