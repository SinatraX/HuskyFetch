﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class Grass : StaticGraphicObject
    {
        public static LevelEditorObject GetLEObject()
        {
            // Sets object's properties for designing
            return new LevelEditorObject(16, 16, 2, 1, ObjectType.OT_Grass, null);
        }
        public static Grass SetLEObject(LevelEditorObject le)
        {
            return new Grass(le.x, le.y);
        }

        public override void Draw()
        {
            base.Draw();
        }
        // In game properties
        public Grass(int x, int y)
        {
            ImageIndex = 1;
            this.x = x;
            this.y = y;
            OT = ObjectType.OT_Grass;
            SetWidthHeight();

        }
    }


}
