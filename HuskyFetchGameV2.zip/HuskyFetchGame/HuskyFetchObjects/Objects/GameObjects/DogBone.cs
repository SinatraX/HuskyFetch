﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class DogBone : AnimatedGraphicObject
    {
        public Boolean MoveUp;
        public double YOff;
        public static LevelEditorObject GetLEObject()
        {
            // Sets object's properties for designing
            return new LevelEditorObject(16, 16, 4, 0, ObjectType.OT_Bone, null);
        }

        public static DogBone SetLEObject(LevelEditorObject le)
        {
            return new DogBone(le.x, le.y, false);
        }

        // For when a dog bone is what comes out of the brickquestion object
        public void MoveBoneUp()
        {
            if (MoveUp == false)
            {
                MoveUp = true;
                YOff = 0;
            }

        }

        public override void Draw()
        {
            base.Draw();
        }
        
        // In game properties for dog bone 
        public override void OnAnimate(object sender, EventArgs e)
        {
            base.OnAnimate(sender, e);
            if (MoveUp)
            {
                Visible = true;
                Animated = true;

                YOff += 0.5;
                newy -= 6 + (int)YOff;


                if (YOff >= 2)
                {
                    MoveUp = false;
                    Visible = false;
                    Animated = false;
                }
            }
        }
        public DogBone(int x, int y, Boolean MovingBone)
            : base(ObjectType.OT_Bone)
        {
            if (MovingBone)
            {
                Visible = false;
                Animated = false;
            }
            // Keeps bones in decent rotation of its picture index
            AnimatedCount = 4;
            this.x = x;
            this.y = y;
            MoveUp = false;


            SetWidthHeight();
            TimerGenerator.AddTimerEventHandler(TimerType.TT_100, OnAnimate);
        }

    }

}
