﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class ProfessorGrant : MoveableAnimatedObject
    {
        public Boolean FallDie;

        public static LevelEditorObject GetLEObject()
        {
            return new LevelEditorObject(16, 16, 4, 1, ObjectType.OT_Grant, null);
        }

        public static ProfessorGrant SetLEObject(LevelEditorObject le)
        {
            return new ProfessorGrant(le.x, le.y);
        }

        // Method Intersection contains a series of code for how
        // Grant will interact with itself, bricks, and Husky
        public override void Intersection(Collision c, GraphicObject g)
        {
            base.Intersection(c, g);

            switch (g.OT)
            {
                case ObjectType.OT_BrickQuestion:
                    {
                        int a = 1;
                    } break;
                case ObjectType.OT_Grant:
                    {
                        DirX *= -1;
                        OnWalk(null, null);
                        ((ProfessorGrant)g).DirX *= -1;
                        ((ProfessorGrant)g).OnWalk(null, null);
                    } break;
                case ObjectType.OT_Husky:
                    {
                        Husky h = (Husky)g;
                        if (c.Dir != CollisionDirection.CD_Down)
                        {
                            if (!h.Blinking)
                            {
                                h.HuskyHandleCollision();
                            }
                        }

                    } break;
            }
        }

        // HuskyGrantFall takes a life when Husky is falling and lands without crushing it
        public void HuskyGrantFall()
        {
            if (FallDie == false)
            {
                FallDie = true;

            }
        }

        // HuskyGrantDie is intended to take a life when interacted directly
        public void HuskyGrantDie()
        {
            Animated = false;
            Live = false;
        }
        
        // OnWalk is intended to set properties of Grant photos to make it walk
        public override void OnWalk(object sender, EventArgs e)
        {
            if (!FallDie)
                base.OnWalk(sender, e);
            else
            {
                Animated = false;
                ImageIndex = 3;
                newy += 3;

                if (newy >= LevelGenerator.CurrentLevel.height)
                {
                    Visible = false;
                }

            }


        }
        public ProfessorGrant(int x, int y)
            : base(ObjectType.OT_Grant)
        {
            AnimatedCount = 2;
            this.x = x;
            this.y = y;
            SetWidthHeight();
            FallDie = false;

            TimerGenerator.AddTimerEventHandler(TimerType.TT_50, this.OnWalk);
            TimerGenerator.AddTimerEventHandler(TimerType.TT_100, this.OnAnimate);
        }
        public override void Draw()
        {
            base.Draw();
        }
        
        // OnAnimate contains animations for what Grant will look like if Husky crushes Grant
        public override void OnAnimate(object sender, EventArgs e)
        {
            if (Visible)
            {
                if (Live)
                    base.OnAnimate(sender, e);
                else
                {
                    if (ImageIndex != 2)
                        ImageIndex = 2; //Die Picture
                    else
                    {
                        Visible = false; //Next Time,Visible False
                    }
                }
            }
        }
    }

}
