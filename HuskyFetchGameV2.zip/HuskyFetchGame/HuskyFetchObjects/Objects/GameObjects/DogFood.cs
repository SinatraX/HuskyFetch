﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class DogFood : AnimatedGraphicObject
    {
        public Boolean MoveUp;
        public double YOff;
        public static LevelEditorObject GetLEObject()
        {
            // Sets object's properties for designing
            return new LevelEditorObject(16, 16, 4, 0, ObjectType.OT_Food, null);
        }

        public static DogFood SetLEObject(LevelEditorObject le)
        {
            return new DogFood(le.x, le.y, false);
        }



        public override void Draw()
        {
            base.Draw();
        }
        public override void OnAnimate(object sender, EventArgs e)
        {
            base.OnAnimate(sender, e);
            if (MoveUp)
            {
                Visible = true;
                Animated = true;

                YOff += 0.5;
                newy -= 6 + (int)YOff;


                if (YOff >= 2)
                {
                    MoveUp = false;
                    Visible = false;
                    Animated = false;
                }
            }
        }

        // In game properties for dog bone
        public DogFood(int x, int y, Boolean MovingDog)
            : base(ObjectType.OT_Food)
        {
            if (MovingDog)
            {
                Visible = false;
                Animated = false;
            }
            // Ensures DogFood stays in position
            AnimatedCount = 1;
            this.x = x;
            this.y = y;
            MoveUp = false;


            SetWidthHeight();
            TimerGenerator.AddTimerEventHandler(TimerType.TT_100, OnAnimate);
        }

    }

}
