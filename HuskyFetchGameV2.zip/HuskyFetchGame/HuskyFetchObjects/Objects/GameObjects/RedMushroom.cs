﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;

namespace HuskyFetchObjects.Objects.GameObjects
{
    
    public class RedMushroom : MoveableAnimatedObject
    {
        public override void OnWalk(object sender, EventArgs e)
        {
            if (Live)
                base.OnWalk(sender, e);
        }

        // Method RedMushroom has similar properties as GreenMushroom, but function is different
        // Goal of this is to make Husky grow when interacted with
        public RedMushroom(int x, int y)
            : base(ObjectType.OT_RedMushroom)
        {
            ImageCount = 2;
            ImageIndex = 0;
            this.x = x;
            this.y = y;
            WalkStep = 2;
            SetWidthHeight();
            Live = false;
            Visible = false;

            TimerGenerator.AddTimerEventHandler(TimerType.TT_50, OnWalk);
        }
    }
}
