﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using HuskyFetchObjects.Objects.GameObjects;
using HuskyFetchObjects.Objects.Utils;
using HuskyFetchObjects.Objects.Patterns;

namespace HuskyFetchObjects.Objects.BaseObjects
{
    public class Level
    {
        public List<IntersectionClass> IntersectsEvents;

        private Collision MainColision = null;

        public Point BottomRight;
        public Point BottomLeft;
        public Point TopRight;
        public Point TopLeft;

        public Boolean ChangeFlagDrawBackground = true;
        public int DrawCountPerCycle = 0;

        public Rectangle AvailableRect;

        public Rectangle DEST;

        public Rectangle SRC;

        public Bitmap LevelBitmap;

        public Husky HuskyObject;

        public int width, height;

        public List<GraphicObject> Objects;

        public VisitorCheckObjectEnabled Visitor_Check_Object_Enabled;


        public void AddObject(GraphicObject g)
        {
            if (g.Objects != null)
                for (int i = 0; i < g.Objects.Count; i++)
                    AddObject(g.Objects[i]);

            Objects.Add(g);
        }

        public void CheckLevelCollisions(Object sender, EventArgs e)
        {

            int cnt = 0;
            int total = 0;


            foreach (GraphicObject src in Objects)
            {
                cnt = 0;
                src.IntersectsObjects.Clear();
                foreach (GraphicObject dest in Objects)
                {

                    if (src != dest)
                        if (src.Visible && dest.Visible)
                        {
                            Collision C = Intersects(src, dest);
                            if (C != null)
                            {
                                src.AddCollision(new IntersectionClass(C, dest, src.Intersection));
                                src.Intersection(C, dest);
                                cnt++;
                            }
                        }
                }


                if (cnt == 0)
                    src.Intersection_None();
            }
        }
        
        // Ref c
        public Boolean Contains(Point Src, Rectangle Dest)
        {
            if ((Src.X >= Dest.X && Src.X <= Dest.X + Dest.Width)
                && (Src.Y >= Dest.Y && Src.Y <= Dest.Y + Dest.Height))
                return true;
            else
                return false;

        }
        public Collision Intersects(GraphicObject SrcObject, GraphicObject DestObject)
        {

            Rectangle Src = SrcObject.GetObjectRect();
            Rectangle Dest = DestObject.GetObjectRect();


            if (Src.X + Src.Width < Dest.X) return null;
            if (Src.Y + Src.Height < Dest.Y) return null;

            if (Src.X > Dest.X + Dest.Width) return null;
            if (Src.Y > Dest.Y + Dest.Height) return null;

            CollisionDirection Dir = CollisionDirection.CD_Down;

            int H, W;
            BottomRight.X = Src.X + Src.Width;
            BottomRight.Y = Src.Y + Src.Height;
            BottomLeft.X = Src.X;
            BottomLeft.Y = Src.Y + Src.Height;
            TopRight.X = Src.X + Src.Width;
            TopRight.Y = Src.Y;
            TopLeft.X = Src.X;
            TopLeft.Y = Src.Y;



            Boolean Found = false;
            // bottom right
            if (Contains(BottomRight, Dest))
            {
                Found = true;
                W = BottomRight.X - Dest.X;
                H = BottomRight.Y - Dest.Y;
                if (W > H)
                    Dir = CollisionDirection.CD_Up;
                else if (H > W)
                    Dir = CollisionDirection.CD_Left;
                else
                    Dir = CollisionDirection.CD_TopLeft;
            }
            // bottom left
            if (Contains(BottomLeft, Dest))
            {
                Found = true;
                W = Dest.X + Dest.Width - BottomLeft.X;
                H = BottomLeft.Y - Dest.Y;
                if (W > H)
                    Dir = CollisionDirection.CD_Up;
                else if (H > W)
                    Dir = CollisionDirection.CD_Right;
                else
                    Dir = CollisionDirection.CD_TopRight;
            }
            // top right
            if (Contains(TopRight, Dest))
            {
                Found = true;
                W = TopRight.X - Dest.X;
                H = Dest.Y + Dest.Height - TopRight.Y;
                if (W > H)
                    Dir = CollisionDirection.CD_Down;
                else
                    Dir = CollisionDirection.CD_Left;
            }
            // top left
            if (Contains(TopLeft, Dest))
            {
                Found = true;
                W = Dest.X + Dest.Width - TopLeft.X;
                H = Dest.Y + Dest.Height - TopLeft.Y;
                if (W > H)
                    Dir = CollisionDirection.CD_Down;
                else
                    Dir = CollisionDirection.CD_Right;
            }

            if (Found == false)
                return null;
            else
            {
                MainColision.Src = Src;
                MainColision.Dest = Dest;
                MainColision.Dir = Dir;
                MainColision.Type = CollisionType.CT_Moveable;
                return MainColision;
            }

        }
        public void AcceptVisitor(VisitorObject V)
        {
            foreach (GraphicObject g in Objects)
                g.AcceptVisitor(V);

        }

        public void UpdateX(int value)
        {
            HuskyObject.SetX(value);
            Update_ScreensX();
        }
        public void UpdateY(int value)
        {
            HuskyObject.y += value;
            Update_ScreensY();
        }

        public void Update_ScreensX()
        {
            if (HuskyObject.x >= Screen.BackgroundScreen.width / 2)
                Screen.BackgroundScreen.x = HuskyObject.x - Screen.BackgroundScreen.width / 2;
            else
                Screen.BackgroundScreen.x = 0;

            if (HuskyObject.x >= Screen.OutputScreen.width / 2)
                Screen.OutputScreen.x = HuskyObject.x - Screen.OutputScreen.width / 2;
            else
                Screen.OutputScreen.x = 0;

            if (HuskyObject.x + Screen.BackgroundScreen.width / 2 >= width)
                Screen.BackgroundScreen.x = width - Screen.BackgroundScreen.width;

            if (HuskyObject.x + Screen.OutputScreen.width / 2 >= width)
                Screen.OutputScreen.x = width - Screen.OutputScreen.width;
        }

        public void Update_ScreensY()
        {
            if (height - HuskyObject.y >= Screen.BackgroundScreen.height / 2)
                Screen.BackgroundScreen.y = height - HuskyObject.y - Screen.BackgroundScreen.height / 2;
            else
                Screen.BackgroundScreen.y = 0;

            if (height - HuskyObject.y >= Screen.OutputScreen.height / 2)
                Screen.OutputScreen.y = height - HuskyObject.y - Screen.OutputScreen.height / 2;
            else
                Screen.OutputScreen.y = 0;

            if (height - HuskyObject.y + Screen.BackgroundScreen.height / 2 >= height)
                Screen.BackgroundScreen.y = height - Screen.BackgroundScreen.height;

            if (height - HuskyObject.y + Screen.OutputScreen.height / 2 >= height)
                Screen.OutputScreen.y = height - Screen.OutputScreen.height;
        }

        public Level()
        {
            LevelGenerator.CurrentLevel = this;

            width = 1024;
            height = 464;//464
            Objects = new List<GraphicObject>();
            LevelBitmap = ImageGenerator.GetImage(ObjectType.OT_Background);
            Visitor_Check_Object_Enabled = new VisitorCheckObjectEnabled();

            MainColision = new Collision(new Rectangle(0, 0, 0, 0), new Rectangle(0, 0, 0, 0), CollisionType.CT_Moveable, CollisionDirection.CD_ButtomLeft);
            AvailableRect = new Rectangle(0, 0, 0, 0);
            BottomLeft = new Point(0, 0);
            BottomRight = new Point(0, 0);
            TopRight = new Point(0, 0);
            TopLeft = new Point(0, 0);

            SRC = new Rectangle(0, 0, 0, 0);
            DEST = new Rectangle(0, 0, 0, 0);



            //HuskyObject = new Husky();
            //Objects.Add(HuskyObject);

            IntersectsEvents = new List<IntersectionClass>();
        }
        public void AddObject(int x, int y, GraphicObject Object)
        {


        }
        public void DrawBackground(Rectangle Rect)
        {
            Graphics xGraph;
            //xGraph = Graphics.FromImage(Screen.GetScreen);
            xGraph = Screen.Instance.Background.xGraph;
            //Rectangle dest = new Rectangle(0, 0, Screen.Width, Screen.Height);
            //Rectangle src = new Rectangle(Screen.OutputScreen.x / 3, (LevelBitmap.Height - Screen.Height) - Screen.OutputScreen.y / 3, Screen.Width, Screen.Height);
            //Rectangle dest = new Rectangle(x - Screen.BackgroundScreen.x, y - (LevelGenerator.LevelHeight - Screen.BackgroundScreen.height) + Screen.BackgroundScreen.y, width, height);




            int Y = (LevelGenerator.CurrentLevel.LevelBitmap.Height - Screen.OutputScreen.y / 3);
            Y = Y - (Y - (Rect.Y));
            int X = (Screen.OutputScreen.x / 3) + (Rect.X - Screen.BackgroundScreen.x);

            DEST.X = Rect.X - Screen.BackgroundScreen.x;
            DEST.Y = Rect.Y - (LevelGenerator.LevelHeight - Screen.BackgroundScreen.height) + Screen.BackgroundScreen.y;
            DEST.Width = Rect.Width;
            DEST.Height = Rect.Height;

            SRC.X = X;
            SRC.Y = Y;
            SRC.Width = Rect.Width;
            SRC.Height = Rect.Height;
            //xGraph.DrawImage(LevelBitmap, dest, src, GraphicsUnit.Pixel);
            xGraph.DrawImage(LevelBitmap, DEST, SRC, GraphicsUnit.Pixel);

            //xGraph.Dispose();


        }
        public void DrawBackground()
        {
            Graphics xGraph;
            //xGraph = Graphics.FromImage(Screen.GetScreen);
            xGraph = Screen.Instance.Background.xGraph;

            //Rectangle dest = new Rectangle(0, 0, Screen.Width, Screen.Height);
            //Rectangle src = new Rectangle(Screen.OutputScreen.x / 3, (LevelBitmap.Height - Screen.Height) - Screen.OutputScreen.y / 3, Screen.Width, Screen.Height);
            DEST.X = 0;
            DEST.Y = 0;
            DEST.Width = Screen.Width;
            DEST.Height = Screen.Height;

            SRC.X = Screen.OutputScreen.x / 3;
            SRC.Y = (LevelBitmap.Height - Screen.Height) - Screen.OutputScreen.y / 3;
            SRC.Width = Screen.Width;
            SRC.Height = Screen.Height;

            //xGraph.DrawImage(LevelBitmap, dest, src, GraphicsUnit.Pixel);
            xGraph.DrawImage(LevelBitmap, DEST, SRC, GraphicsUnit.Pixel);

            //xGraph.Dispose();

        }
        public Rectangle GetAvailableObjectRec()
        {
            int AX, AY;

            if (HuskyObject.x < Screen.BackgroundScreen.width / 2)
                AX = 0;
            else if (HuskyObject.x >= Screen.BackgroundScreen.width / 2 && HuskyObject.x < LevelGenerator.CurrentLevel.width - Screen.BackgroundScreen.width / 2)
                AX = HuskyObject.x - Screen.BackgroundScreen.width / 2;
            else
                AX = LevelGenerator.CurrentLevel.width - Screen.BackgroundScreen.width;

            if (HuskyObject.y < Screen.BackgroundScreen.height / 2)
                AY = 0;
            else if (HuskyObject.y >= Screen.BackgroundScreen.height / 2 && HuskyObject.y < LevelGenerator.CurrentLevel.height - Screen.BackgroundScreen.height / 2)
                AY = HuskyObject.y - Screen.BackgroundScreen.height / 2;
            else
                AY = LevelGenerator.CurrentLevel.height - Screen.BackgroundScreen.height;

            // Performance Issue

            AvailableRect.X = AX;
            AvailableRect.Y = AY;
            AvailableRect.Width = Screen.BackgroundScreen.width;
            AvailableRect.Height = Screen.BackgroundScreen.height;
            return AvailableRect;

            //return new Rectangle(AX,AY, Screen.BackgroundScreen.width, Screen.BackgroundScreen.height);
        }


        public void Draw()
        {
            Rectangle AvailableRec = GetAvailableObjectRec();
            int cnt = 0;
            if (ChangeFlagDrawBackground)
            {
                DrawBackground();
                //foreach (GraphicObject g in Objects)
                //    if (AvailableRec.Contains(g.GetObjectRect()))
                //        g.Draw();

                //ChangeFlagDrawBackground = false;
            }
            DrawCountPerCycle = 0;
            foreach (GraphicObject g in Objects)
            {
                // Should Improve Performance. Draw only objects in Range...
                // Rectangle r = g.GetObjectRect();
                if (AvailableRec.Contains(g.GetObjectRect()))
                {
                    g.Draw();
                    //cnt++;
                    //Logger.Instance.WriteLn(g.GetType().ToString());
                }

            }
            //Logger.Instance.WriteLn("Objects:" + cnt.ToString());
            //Logger.Instance.WriteLn("Drown:" + DrawCountPerCycle.ToString());


        }

    }
}
