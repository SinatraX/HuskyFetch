﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.BaseObjects
{
    public class StaticGraphicObject : GraphicObject
    {
        public int ImageIndex;
        public int OffsetIndex;
        public int ImageCount;

        public StaticGraphicObject()
        {
            ImageCount = 1;
            OffsetIndex = 0;

        }
        public override void Draw()
        {
            if (Visible == true)
            {

                if (ObjectChangedDrawFlag)
                {
                    Graphics xGraph;
                    xGraph = Screen.Instance.Background.xGraph;

                    Bitmap b = ImageGenerator.GetImage(OT);

                    DEST.X = newx - Screen.BackgroundScreen.x;
                    DEST.Y = newy - (LevelGenerator.LevelHeight - Screen.BackgroundScreen.height) + Screen.BackgroundScreen.y;
                    DEST.Width = b.Width / ImageCount;
                    DEST.Height = b.Height;

                    SRC.X = width * (ImageIndex + OffsetIndex);
                    SRC.Y = 0;
                    SRC.Width = b.Width / ImageCount;
                    SRC.Height = b.Height;

                    xGraph.DrawImage(b, DEST, SRC, GraphicsUnit.Pixel);
                }
            }
        }

    }

}
