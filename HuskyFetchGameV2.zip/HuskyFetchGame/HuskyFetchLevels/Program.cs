using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace HuskyFetchLevels
{
    static class Program
    {
        /// <summary>
        /// Run form editor.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}