using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

using Helper;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.GameObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects
{
    public partial class frmMain : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        private const int WM_PAINT = 0x000F;


        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("User32.dll")]
        private static extern short GetAsyncKeyState(System.Windows.Forms.Keys vKey); 

        public Level lev;
        public int BackPaint = 0;

        DateTime LevelBeginTime;
        

        // Run it :D
        public frmMain()
        {
            InitializeComponent();
        }

        // Establishes window properties of the main game window
        // Need to modify to account for maximizing window
        public void InGame_Properties()
        {
            Width = 320;
            Height = 240  + 40 + flowPanel_gameInfo.Height;

            pMain.Image = new Bitmap(320,240);
            
            Left = SystemInformation.PrimaryMonitorSize.Width / 2 - this.Width / 2;
            Top = SystemInformation.PrimaryMonitorSize.Height / 2 - this.Height / 2;
            
        }

        // Loads the xml file that holds the levels
        private void MainForm_Load(object sender, EventArgs e)
        {
            LevelManager.Instance.InitLevelManager("LevelManager.xml");
            Load_Level(LevelManagerLoadTypes.STARTUP);
        }

        // Information for top window and game panel
        private void timerPaint_Tick(object sender, EventArgs e)
        {
            pMain.Invalidate();
            DateTime TimeClose = DateTime.Now;
            TimeSpan Diff = TimeClose.Subtract(LevelBeginTime);
            this.Text = string.Format("{0:00}:{1:00}:{2:00}", Diff.Hours, Diff.Minutes, Diff.Seconds);
            lbl_Level.Text = "Level " + (LevelManager.Instance.CurrentLevelIndex + 1).ToString() + " (" + LevelManager.Instance.CurrentLevelName + ")";
            lbl_numCoins.Text = lev?.HuskyObject?.NumberOfCollectedBones.ToString();
            lbl_numFood.Text = lev?.HuskyObject?.NumberOfCollectedFood.ToString();
            lbl_numLives.Text = LevelManager.Instance.HuskyLives.ToString();
        }

        // When pressing down key
        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            Boolean KeyRight = false;
            Boolean KeyLeft = false;

            int state = Convert.ToInt32(GetAsyncKeyState(Keys.Right).ToString());
            KeyRight = (state == -32767);
            state = Convert.ToInt32(GetAsyncKeyState(Keys.Left).ToString());
            KeyLeft = (state == -32767);

            if (e.KeyValue == (int)Keys.Up)
                lev.HuskyObject.StartJump(false,0);

            if (e.KeyValue == (int)Keys.Right || KeyRight)
                lev.HuskyObject.HuskyMove(Husky.HuskyMoveState.Jump_Right);

            if (e.KeyValue == (int)Keys.Left || KeyLeft)
                lev.HuskyObject.HuskyMove(Husky.HuskyMoveState.Jump_Left);

            if (e.KeyValue == (int)Keys.Space)
                lev.HuskyObject.HuskyFireBall(); 

            
            if(e.KeyValue == (int)Keys.Enter)
                lev.HuskyObject.EnterPressed = true;

            if (e.KeyValue == (int)Keys.Escape)
                this.Close();
        }

        // When up key is pressed
        private void frmMain_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (int)Keys.ControlKey)
                lev.HuskyObject.StopJump();

            if (e.KeyValue == (int)Keys.Right)
                lev.HuskyObject.StopMove();


            if (e.KeyValue == (int)Keys.Left)
                lev.HuskyObject.StopMove();

            if (e.KeyValue == (int)Keys.Up)
                lev.HuskyObject.UpPressed = false;
        }


        // Loading level
        public void Load_Level(LevelManagerLoadTypes levelLoadType)
        {
            TimerGenerator.RemoveAllTimerEvents();

            InGame_Properties();

            lev = LevelManager.Instance.LoadLevel(levelLoadType);

            lev.HuskyObject.OnLevelCompleted += (() => Load_Level(LevelManagerLoadTypes.NEXT));
            lev.HuskyObject.OnHuskyDied += (() => Load_Level(LevelManagerLoadTypes.RELOAD));

            lev.HuskyObject.x = 20;
            lev.HuskyObject.y = LevelGenerator.LevelHeight - 16 * 1 - lev.HuskyObject.height;
            LevelGenerator.CurrentLevel.Update_ScreensX();
            LevelGenerator.CurrentLevel.Update_ScreensY();

            LevelBeginTime = DateTime.Now;

            Invalidate();
        }

        private void frmMain_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void pMain_MouseDown(object sender, MouseEventArgs e)
        {
            frmMain_MouseDown(sender, e);
        }

        private void pMain_Paint(object sender, PaintEventArgs e)
        {
            Graphics xGraph = e.Graphics; 
            lev.Draw();
            HuskyFetchObjects.Objects.Utils.Screen.Instance.DrawOnGraphic(xGraph);      
        }

        private void timerBack_Tick(object sender, EventArgs e)
        {
            Invalidate();
        }

        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            LevelManager.Instance.SaveLevelManager("LevelManager.xml");

            DateTime TimeClose = DateTime.Now;
            TimeSpan Diff = TimeClose.Subtract(LevelBeginTime);
            Logger.Instance.Log_Method(Diff.ToString());
        }
    }
}