﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class SolidPlatform : StaticGraphicObject
    {
        public static LevelEditorObject GetLEObject()
        {
            // Sets object's properties for designing 
            return new LevelEditorObject(16, 16, 1, 0, ObjectType.OT_SolidPlatform, null);
        }
        public static SolidPlatform SetLEObject(LevelEditorObject le)
        {
            return new SolidPlatform(le.x, le.y);
        }
        // In game props
        public SolidPlatform(int x, int y)
        {
            this.x = x;
            this.y = y;
            SetWidthHeight();
            OT = ObjectType.OT_SolidPlatform;

        }
    }

}
