﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class FinishDoor : StaticGraphicObject
    {
        public static LevelEditorObject GetLEObject()
        {
            // Sets object's properties for designing
            return new LevelEditorObject(16, 32, 1, 0, ObjectType.OT_FinishDoor, null);
        }

        public static FinishDoor SetLEObject(LevelEditorObject le)
        {
            return new FinishDoor(le.x, le.y);
        }

        // In game properties
        public FinishDoor(int x, int y)
        {
            OT = ObjectType.OT_FinishDoor;
            this.x = x;
            this.y = y;
            SetWidthHeight();
            width = 16;

        }
    }

}
