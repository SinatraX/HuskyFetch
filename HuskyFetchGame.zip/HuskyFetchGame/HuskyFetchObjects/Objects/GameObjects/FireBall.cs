﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class FireBall : AnimatedGraphicObject
    {
        public enum FireBallType { FT_Husky, FT_Goda };
        public enum FireBallDir { FB_Right, FB_Left };
        public double StartVelocity;
        public double StartPosition;
        public double TimeCount;
        public FireBallDir Direction;
        public int Dirx;
        public Boolean Started;
        public FireBallType Type;

        public Boolean Fire;
        public double OffX, OffY;
        public double CntX, CntY;

        // Intended for how the fireball interacts with several HuskyFetch objects
        public override void Intersection(Collision c, GraphicObject g)
        {
            base.Intersection(c, g);
            switch (g.OT)
            {
                case ObjectType.OT_SolidPlatform:
                    goto case ObjectType.OT_Pipe;
                case ObjectType.OT_BrickQuestion:
                    goto case ObjectType.OT_Grass;
                case ObjectType.OT_Brick:
                    goto case ObjectType.OT_Grass;

                case ObjectType.OT_Grass:
                {
                    StartFireBall();
                    break;
                } 
                case ObjectType.OT_Pipe:
                {
                    Started = false;
                    Visible = false;
                    break;
                } 
                case ObjectType.OT_Grant:
                {
                    if (Type == FireBallType.FT_Husky)
                    {
                        ((ProfessorGrant)g).HuskyGrantFall();

                        Started = false;
                        Visible = false;
                    }
                    break;
                } 
                case ObjectType.OT_Suri:
                {
                    if (Type == FireBallType.FT_Husky)
                    {
                        ((ProfessorSuri)g).SetKoopaState(ProfessorSuri.SuriState.SuriState_Shield);

                        Started = false;
                        Visible = false;
                    }
                    break;
                } 
                case ObjectType.OT_Goda:
                {
                    if (Type == FireBallType.FT_Husky && ((ProfessorGoda)g).Move != ProfessorGoda.GodaMovement.GM_None) // Only kill pirana if it's out of its pipe
                    {
                        ((ProfessorGoda)g).Visible = false;
                        ((ProfessorGoda)g).Live = false;
                    }
                    break;
                } 
                // Handle fireball hitting Husky
                case ObjectType.OT_Husky:
                {
                    if (Type != FireBallType.FT_Husky) // Make sure it isn't Husky's fireball
                    {
                        Husky h = (Husky)g;
                        if (!h.Blinking)
                        {
                            h.HuskyHandleCollision();
                        }
                    }
                    break;
                } 
            }
        } 

        // Makes the Fireball move
        public void RunFireBall(int x, int y, FireBallType T, FireBallDir D)
        {
            Type = T;
            Direction = D;
            if (Type == FireBallType.FT_Husky)
            {
                if (D == FireBallDir.FB_Right)
                    Dirx = 1;
                else
                    Dirx = -1;
            }
            if (Type == FireBallType.FT_Goda)
            {

            }

            SetFireProperties();
            newx = x;
            newy = y;

            StartFireBall();
        }
        public void StartFireBall()
        {
            Fire = true;
            Visible = true;
            StartPosition = newy;
            if (Started == false)
                StartVelocity = 0;
            else
                StartVelocity = -15;

            Started = true;
            TimeCount = 0;
        }

        // SetFireballPosition is intended to run the fireball animation
        // for a set amount of time all over the place
        public double SetFireballPosition()
        {
            return StartPosition + StartVelocity * TimeCount + 4.9 * TimeCount * TimeCount;
        }

        public override void Draw()
        {
            base.Draw();
        }
        public override void OnAnimate(object sender, EventArgs e)
        {
            base.OnAnimate(sender, e);
        }
        public void SetOffXY(double x, double y)
        {
            OffX = x;
            OffY = y;

            CntX = 0;
            CntY = 0;


        }
        
        // OnFire is for ensuring that Goda in fire state and
        // Husky in fire state throw fire accurately
        public void OnFire(object sender, EventArgs e)
        {
            if (Started)
            {
                if (Fire)
                {
                    if (Type == FireBallType.FT_Husky)
                    {
                        TimeCount += (250.0 / 1000.0);
                        newy = (int)SetFireballPosition();

                        newx += 5 * Dirx;
                    }
                    if (Type == FireBallType.FT_Goda)
                    {
                        //CntX += OffX;
                        //CntY += OffY;

                        newx += (int)OffX;
                        newy += (int)OffY;
                    }

                    if (newy < 0)
                        Started = false;

                    if (newx >= LevelGenerator.CurrentLevel.HuskyObject.x + 320)
                    {
                        Started = false;
                        Visible = false;
                    }
                    if (newx < LevelGenerator.CurrentLevel.HuskyObject.x - 320)
                    {
                        Started = false;
                        Visible = false;
                    }
                }
            }

        }

        public void SetFireProperties()
        {
            this.x = x;
            this.y = y;
            SetWidthHeight();
            width = 8;
            height = 9;

        }
        
        // In game properties
        public FireBall(int x, int y)
            : base(ObjectType.OT_FireBall)
        {

            Fire = false;
            Visible = false;
            AnimatedCount = 4;

            TimerGenerator.AddTimerEventHandler(TimerType.TT_100, OnAnimate);
            TimerGenerator.AddTimerEventHandler(TimerType.TT_50, OnFire);
        }
    }

}
