﻿using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;
using System;
using System.Collections.Generic;
using System.Drawing;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class Husky : AnimatedGraphicObject
    {
        public enum HuskyJumpState { Jump_None, Jump_Up, Jump_Down };
        public enum HuskyMoveState { Jump_None, Jump_Right, Jump_Left, Jump_Stopping };
        public enum HuskyType { MT_Small, MT_Big, MT_Fire };
        public enum HuskyDir { Key_Left, Key_Right };
        public Boolean Moving;
        public Boolean Jumping;
        public HuskyDir Direction;
        public HuskyType Type;
        public HuskyJumpState State;
        public HuskyMoveState MoveState;
        public Boolean EnterPressed;
        public Boolean Blinking;
        public Boolean BlinkingShow;
        public int BlinkValue;

        // Y Jumping
        public double StartVelocity;
        public double StartPosition;
        public double CurrentPosition;
        public double OldPosition;
        public double TimeCount;

        //X Moving
        public double XCount;
        public double XAdd;

        public Boolean UpPressed;

        public List<FireBall> FireBalls;
        public int FireBallIndex;

        /// <summary>
        /// Number of bones and food Husky collected in the current level
        /// </summary>
        public int NumberOfCollectedBones { get; set; }

        public int NumberOfCollectedFood { get; set; }

        public static LevelEditorObject GetLEObject()
        {
            return new LevelEditorObject(16, 16, 6, 2, ObjectType.OT_Husky, null);
        }
        public static Husky SetLEObject(LevelEditorObject le)
        {
            return new Husky(le.x, le.y);
        }


        public delegate void LevelCompletedDelegate();
        public event LevelCompletedDelegate OnLevelCompleted;

        public delegate void HuskyDiedDelegate();
        public event HuskyDiedDelegate OnHuskyDied;


        public void OnCheckCollisions(Object sender, EventArgs e)
        {
            LevelGenerator.Raise_Event(LevelGenerator.LevelEvent.LE_Check_Collision);
        }
        public void HuskyFireBall()
        {
            if (Type != HuskyType.MT_Fire)
                return;

            FireBall.FireBallDir D;
            if (!FireBalls[FireBallIndex].Started)
            {
                if (Direction == HuskyDir.Key_Right)
                    D = FireBall.FireBallDir.FB_Right;
                else
                    D = FireBall.FireBallDir.FB_Left;


                FireBalls[FireBallIndex].RunFireBall(x, y, FireBall.FireBallType.FT_Husky, D);
                FireBallIndex = (FireBallIndex + 1) % 2;
            }

        }
        public override Rectangle GetObjectRect()
        {
            if (Type == HuskyType.MT_Small)
                return new Rectangle(x, y, 16, 16);
            if (Type == HuskyType.MT_Big)
                return new Rectangle(x, y, 16, 27);
            if (Type == HuskyType.MT_Fire)
                return new Rectangle(x, y, 16, 27);
            else
                return Rectangle.Empty;
        }
        public override void Intersection_None()
        {
            base.Intersection_None();

            if (State == HuskyJumpState.Jump_None)
            {
                State = HuskyJumpState.Jump_Down;
                StartPosition = y;
                TimeCount = 0;
                StartVelocity = 0;

            }

        }

        // 
        public void HuskyDie()
        {
            NumberOfCollectedBones = 0;
            NumberOfCollectedFood = 0;
            OnHuskyDied?.Invoke();
        }

        // This is intended for what will happen to the Husky if it
        // interacts with certain objects in either it's normal, large, or fire state
        public void HuskyHandleCollision()
        {
            switch (Type)
            {
                case HuskyType.MT_Fire:
                    {
                        Type = Husky.HuskyType.MT_Big;
                        StartBlinking();
                        SetHuskyProperties();
                        break;
                    }
                case HuskyType.MT_Big:
                    {
                        Type = Husky.HuskyType.MT_Small;
                        StartBlinking();
                        SetHuskyProperties();
                        break;
                    }
                case HuskyType.MT_Small:
                    {
                        HuskyDie();
                        break;
                    }
            }
        }
        // Boolean to help with when the Husky interacts with the brick object from the right side
        public bool BrickOnRightSide()
        {
            Boolean res = false;

            for (int i = 0; i < IntersectsObjects.Count; i++)
                if (IntersectsObjects[i].G != null && (IntersectsObjects[i].G.OT == ObjectType.OT_Brick || IntersectsObjects[i].G.OT == ObjectType.OT_SolidPlatform))
                    if (IntersectsObjects[i].C.Dir == CollisionDirection.CD_Right)
                        res = true;

            return res;
        }

        // Boolean to help with when the Husky interacts with the brick object from the left side 
        public bool BrickOnLeftSide()
        {
            Boolean res = false;

            for (int i = 0; i < IntersectsObjects.Count; i++)
                if (IntersectsObjects[i].G != null && (IntersectsObjects[i].G.OT == ObjectType.OT_Brick || IntersectsObjects[i].G.OT == ObjectType.OT_SolidPlatform))
                    if (IntersectsObjects[i].C.Dir == CollisionDirection.CD_Left)
                        res = true;

            return res;
        }
        
        // Method Intersection responsible for how the Husky should react
        // when interacting with objects in game
        public override void Intersection(Collision c, GraphicObject g)
        {
            base.Intersection(c, g);
            switch (g.OT)
            {
                // How Husky interacts with exit door. Hitting enter moves to the next level
                case ObjectType.OT_FinishDoor:
                    {
                        if (EnterPressed)
                        {
                            EnterPressed = false;
                            OnLevelCompleted?.Invoke();                      
                        }
                        break;
                    }
                // How Husky interacts with the fireballs
                case ObjectType.OT_Flower:
                    {
                        ((Flower)g).Visible = false;
                        if (Type != HuskyType.MT_Fire)
                        {
                            Type = HuskyType.MT_Fire;
                            SetHuskyProperties();
                        }
                        break;
                    }
                // How Husky interacts with the red mushroom increase size of the husky
                case ObjectType.OT_RedMushroom:
                    {
                        ((RedMushroom)g).Visible = false;
                        ((RedMushroom)g).Animated = false;
                        ((RedMushroom)g).Live = false;
                        if (Type == HuskyType.MT_Small)
                        {
                            Type = HuskyType.MT_Big;
                            SetHuskyProperties();
                        }
                        break;
                    }
                // How Husky interacts with the green mushrooms that
                // will increase the number of lives husky has per level
                case ObjectType.OT_GreenMushroom:
                    {
                        ((GreenMushroom)g).Visible = false;
                        ((GreenMushroom)g).Animated = false;
                        ((GreenMushroom)g).Live = false;
                        LevelManager.Instance.HuskyLives++;
                        break;
                    }
                // How Husky interacts with collecting dog bones
                // Works similar to the coins in Mario
                case ObjectType.OT_Bone:
                    {
                        ((DogBone)g).Animated = false;
                        ((DogBone)g).Visible = false;
                        NumberOfCollectedBones++;
                        break;
                    }

                // How Husky interacts with collecting dog food
                // Works similar dog bones
                case ObjectType.OT_Food:
                    {
                        ((DogFood)g).Animated = false;
                        ((DogFood)g).Visible = false;
                        NumberOfCollectedFood++;
                        break;
                    }

                // How Husky interacts with the running Grants
                // These are intended to remove a life
                case ObjectType.OT_Grant:
                    {
                        if (c.Dir == CollisionDirection.CD_Up)
                        {
                            if (((ProfessorGrant)g).FallDie == false)    // Jump On Goomba with Up Presses
                            {
                                if (UpPressed)
                                    StartJump(true, 0);
                                else
                                    StartJump(true, -20);

                                ((ProfessorGrant)g).HuskyGrantDie();
                            }
                        }
                        break;
                    }
                
                // How Husky interacts with the Suri's that will come out of the pipes
                // Intended to damage Husky
                case ObjectType.OT_Goda:
                    {
                        if (c.Dir == CollisionDirection.CD_Up)      // Jump On Piranah with Up Presses
                        {
                            if (UpPressed)
                                StartJump(true, 0);
                            else
                                StartJump(true, -20);

                            ((ProfessorGoda)g).HuskyGodaDie();
                        }
                        break;
                    }
                
                // How Husky's will interact with the Goda's
                // Will make Husky lose a life
                case ObjectType.OT_Suri:
                    {
                        if (c.Dir == CollisionDirection.CD_Up)  // Jump On Koopa with Up Presses
                        {
                            if (((ProfessorSuri)g).State == ProfessorSuri.SuriState.SuriState_Walking)
                            {
                                if (UpPressed)
                                    StartJump(true, 0);
                                else
                                    StartJump(true, -20);

                                ((ProfessorSuri)g).SetKoopaState(ProfessorSuri.SuriState.SuriState_Shield);
                            }
                            else
                            {
                                if ((((ProfessorSuri)g).State == ProfessorSuri.SuriState.SuriState_Shield) && (((ProfessorSuri)g).ReturningTime >= 3))
                                {
                                    ((ProfessorSuri)g).SetKoopaState(ProfessorSuri.SuriState.SuriState_ShieldMoving);

                                }
                                else if (((ProfessorSuri)g).State == ProfessorSuri.SuriState.SuriState_ShieldMoving)
                                {
                                    if (UpPressed)
                                        StartJump(true, 0);
                                    else
                                        StartJump(true, -20);

                                    ((ProfessorSuri)g).SetKoopaState(ProfessorSuri.SuriState.SuriState_Shield);
                                }
                            }
                        }
                        break;
                    }
                // The following cases for the object types are intended to help
                // for the Husky landing on these objects correctly in the game.
                case ObjectType.OT_MovingPlatform:
                    goto case ObjectType.OT_Grass;
                case ObjectType.OT_SolidPlatform:
                    goto case ObjectType.OT_Grass;
                case ObjectType.OT_Pipe:
                    goto case ObjectType.OT_Grass;
                case ObjectType.OT_BrickQuestion:
                    goto case ObjectType.OT_Grass;
                case ObjectType.OT_BrickQuestionHidden:
                    goto case ObjectType.OT_Grass;
                case ObjectType.OT_Brick:
                    goto case ObjectType.OT_Grass;
                case ObjectType.OT_Grass:
                    {
                        SetDirections();

                        if (c.Dir == CollisionDirection.CD_TopLeft)
                        {
                            if (g.OT == ObjectType.OT_Brick)
                            {
                            }
                        }
                        if (c.Dir == CollisionDirection.CD_Up)
                        {
                            if (g.OT == ObjectType.OT_MovingPlatform)
                            {
                                this.y = g.newy - this.height;
                                ((MovingPlatform)g).HuskyOn = true;
                            }
                            else
                            {
                                if (State != HuskyJumpState.Jump_None)
                                    this.y = g.newy - this.height;
                            }
                            if (State != HuskyJumpState.Jump_None)
                            {
                                State = HuskyJumpState.Jump_None;
                            }
                            SetDirections();
                        }

                        if (c.Dir == CollisionDirection.CD_Left)
                        {
                            this.x = g.newx - width;
                            if (g.OT == ObjectType.OT_Brick)
                            {
                                this.x = g.newx - width;
                            }
                        }

                        if (c.Dir == CollisionDirection.CD_Down)
                        {
                            if (State == HuskyJumpState.Jump_Up)
                            {
                                State = HuskyJumpState.Jump_Down;
                                StartPosition = y;
                                TimeCount = 0;
                                StartVelocity = 0;
                                if (g.OT == ObjectType.OT_BrickQuestion || g.OT == ObjectType.OT_BrickQuestionHidden)
                                {
                                    ((BrickQuestion)g).ProfessorExist();
                                    ((BrickQuestion)g).StartMove();
                                    if (((BrickQuestion)g).HiddenObject.OT != ObjectType.OT_Bone)
                                    {
                                    }
                                    else
                                    {
                                        NumberOfCollectedBones++;
                                    }
                                }
                                if (g.OT == ObjectType.OT_Brick)
                                {
                                    if (Type == HuskyType.MT_Big || Type == HuskyType.MT_Fire)
                                    {
                                        ((Brick)g).BreakBrick();
                                    }
                                    else
                                    {
                                    }

                                }
                            }

                        }
                        if (c.Dir == CollisionDirection.CD_Right)
                        {
                            this.x = g.newx + g.width;
                        }
                        break;
                    }
            }
        }

        public void SetX(int x)
        {
            if (x > 0)
                Direction = HuskyDir.Key_Right;
            else
                Direction = HuskyDir.Key_Left;

            this.x += x;
            SetDirections();
            Moving = true;
        }

        public override void Draw()
        {
            if (BlinkingShow)
            {
                if (ObjectChangedDrawFlag)
                {
                    Graphics xGraph;
                    xGraph = Screen.Instance.Background.xGraph;
                    Bitmap b = null;
                    if (Type == HuskyType.MT_Small)
                        b = ImageGenerator.GetImage(ObjectType.OT_HuskySmall);
                    if (Type == HuskyType.MT_Big)
                        b = ImageGenerator.GetImage(ObjectType.OT_HuskyBig);
                    if (Type == HuskyType.MT_Fire)
                        b = ImageGenerator.GetImage(ObjectType.OT_HuskyFire);

                    Rectangle dest = new Rectangle(x - Screen.BackgroundScreen.x, y - (LevelGenerator.LevelHeight - Screen.BackgroundScreen.height) + Screen.BackgroundScreen.y, width, height);
                    Rectangle src = new Rectangle(16 * ImageIndex, 0, b.Width / 6, b.Height);

                    xGraph.DrawImage(b, dest, src, GraphicsUnit.Pixel);
                }
            }

        }

        // Method SetDirections is intended to make the Husky appear to move based on moving left to right
        public void SetDirections()
        {
            if (State == HuskyJumpState.Jump_None)
            {
                if (Direction == HuskyDir.Key_Left)
                    ImageIndex = 0;

                if (Direction == HuskyDir.Key_Right)
                    ImageIndex = 9;

            }
            else if (Moving)
            {
                if (Direction == HuskyDir.Key_Left)
                    if (ImageIndex == 0)
                        ImageIndex = 0;
                    else
                        ImageIndex = 0;

                if (Direction == HuskyDir.Key_Right)
                    if (ImageIndex == 0)
                        ImageIndex = 0;
                    else
                        ImageIndex = 0;
            }
            else
            {
                if (Direction == HuskyDir.Key_Right)
                    ImageIndex = 0;

                if (Direction == HuskyDir.Key_Left)
                    ImageIndex = 9;
            }

        }

        // For what happens when the Husky is not jumping
        // or how it lands after fall
        public void StopJump()
        {
            UpPressed = false;
            if (State != HuskyJumpState.Jump_None)
            {
                State = HuskyJumpState.Jump_Down;
                StartPosition = y;
                TimeCount = 0;
                StartVelocity = 0;
            }

        }
        // When up key is pressed the husky will jump
        public void StartJump(Boolean Kill, double DefeaultVelocity)
        {
            if (Kill == false)
                UpPressed = true;

            if (State == HuskyJumpState.Jump_None || Kill == true)
            {
                State = HuskyJumpState.Jump_Up;
                StartPosition = y;
                OldPosition = y;
                CurrentPosition = y;
                TimeCount = 0;
                if (DefeaultVelocity != 0)
                    StartVelocity = DefeaultVelocity;
                else
                    StartVelocity = -38;
            }

        }

        // For making husky jump on time
        public double CalcHuskyJumpPosition()
        {//http://study.eitan.ac.il/sites/index.php?portlet_id=110529&page_id=13
            return StartPosition + StartVelocity * TimeCount + 4.9 * TimeCount * TimeCount;
        }

        // Properties for how high the Husky will jump
        public void HuskyJumps(Object sender, EventArgs e)
        {
            if (State != HuskyJumpState.Jump_None)
            {
                SetDirections();
                TimeCount += (350.0 / 1000.0);
                OldPosition = CurrentPosition;
                CurrentPosition = CalcHuskyJumpPosition();
                if (State == HuskyJumpState.Jump_Up)
                    y = (int)(CurrentPosition);
                else
                    y += 6 + (int)TimeCount;

                LevelGenerator.CurrentLevel.Update_ScreensY();

                if (State == HuskyJumpState.Jump_Up)
                    if (CurrentPosition > OldPosition)
                    {
                        State = HuskyJumpState.Jump_Down;
                        TimeCount = 0;
                    }
            }
            else
            {
                TimeCount = 0;
            }
        }

        // HuskyMove responds to the up,down,left, and right keys on keyboard
        public void HuskyMove(HuskyMoveState s)
        {
            MoveState = s;

            if (Direction != HuskyDir.Key_Left)
                if (s == HuskyMoveState.Jump_Left)
                    Direction = HuskyDir.Key_Left;

            if (Direction != HuskyDir.Key_Right)
                if (s == HuskyMoveState.Jump_Right)
                    Direction = HuskyDir.Key_Right;
        }

        // Husky stops moving if not holding any keys
        public void StopMove()
        {

            if (MoveState != HuskyMoveState.Jump_Stopping)
            {

                switch (MoveState)
                {
                    case HuskyMoveState.Jump_Left:
                        Direction = HuskyDir.Key_Left; break;

                    case HuskyMoveState.Jump_Right:
                        Direction = HuskyDir.Key_Right; break;
                }

                MoveState = HuskyMoveState.Jump_Stopping;

                if (!UpPressed)
                {
                    XCount = 5;
                    XAdd = 0;
                }
            }

        }
        
        // Answers what happens to other objects or the husky itself
        // while it's is on the move 
        public void HuskyOnMove(Object sender, EventArgs e)
        {
            if (y > LevelGenerator.CurrentLevel.height + 50)
            {
                HuskyDie();
            }

            if (MoveState != HuskyMoveState.Jump_None && MoveState != HuskyMoveState.Jump_Stopping)
            {
                Moving = true;
                SetDirections();
                LevelGenerator.CurrentLevel.Update_ScreensX();

                if (XAdd < 3)
                    XAdd += 0.5;
                if (!BrickOnLeftSide())
                {
                    if (MoveState == HuskyMoveState.Jump_Right)
                        x += 3 + (int)XAdd;
                }
                if (!BrickOnRightSide())
                {

                    if (MoveState == HuskyMoveState.Jump_Left)
                        x -= 3 + (int)XAdd;
                }
            }
            if (MoveState == HuskyMoveState.Jump_Stopping)
            {
                Moving = true;
                SetDirections();
                LevelGenerator.CurrentLevel.Update_ScreensX();

                XCount = Math.Sqrt(XCount);

                if (Direction == HuskyDir.Key_Right)
                    x += (int)XCount;

                if (Direction == HuskyDir.Key_Left)
                    x -= (int)XCount;

                if (XCount < 1.05)
                {
                    MoveState = HuskyMoveState.Jump_None;
                    Moving = false;
                }
            }
        }

        // Animation props
        public override void OnAnimate(object sender, EventArgs e)
        {

            if (Blinking)
            {
                BlinkValue++;
                BlinkingShow = (BlinkValue % 2 == 0);

                if (BlinkValue == 20)
                {
                    Blinking = false;
                    BlinkingShow = true;
                }
            }
        }

        public void SetHuskyProperties()
        {
            if (Type == HuskyType.MT_Small)
            {
                width = 28; //28
                height = 16; //16
                y += 8; //11
            }
            if (Type == HuskyType.MT_Big)
            {
                width = 56;  //56
                height = 27; //32
                y -= 8; //11
            }
            if (Type == HuskyType.MT_Fire)
            {
                width = 16;
                height = 27;
                y -= 11;
            }
        }

        // If husky is in another state and incorrectly interacts with the professors
        public void StartBlinking()
        {
            if (Blinking == false)
            {
                Blinking = true;
                BlinkValue = 0;
            }
        }
        public Husky(int x, int y)
            : base(ObjectType.OT_Husky)
        {
            FireBalls = new List<FireBall>();
            for (int i = 0; i < 2; i++)
                FireBalls.Add(new FireBall(0, 0));

            for (int i = 0; i < 2; i++)
                AddObject(FireBalls[i]);

            Type = HuskyType.MT_Small;
            SetHuskyProperties();

            this.x = x * 16;
            this.y = LevelGenerator.LevelHeight - 16 * y - height;
            Visible = true;
            UpPressed = false;
            Blinking = false;
            BlinkingShow = true;
            NumberOfCollectedBones = 0;
            NumberOfCollectedFood = 0;

            Moving = false;
            Jumping = false;
            Direction = HuskyDir.Key_Right;


            State = HuskyJumpState.Jump_None;
            MoveState = HuskyMoveState.Jump_None;

            TimerGenerator.AddTimerEventHandler(TimerType.TT_100, OnAnimate);
            TimerGenerator.AddTimerEventHandler(TimerType.TT_50, HuskyJumps);
            TimerGenerator.AddTimerEventHandler(TimerType.TT_50, HuskyOnMove);
            TimerGenerator.AddTimerEventHandler(TimerType.TT_50, OnCheckCollisions);

        }

    }


}
