﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;

namespace HuskyFetchObjects.Objects.GameObjects
{
    // Flower is for the flower object that puts the Husky
    // into a fire state where they user can also spit out fire
    public class Flower : StaticGraphicObject
    {
        public override void Draw()
        {
            base.Draw();
        }
        public Flower(int x, int y)
        {
            OT = ObjectType.OT_Flower;
            Visible = false;
            this.x = x;
            this.y = y;
            SetWidthHeight();

        }
    }

}
