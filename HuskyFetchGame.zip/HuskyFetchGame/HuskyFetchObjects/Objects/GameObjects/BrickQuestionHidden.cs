﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class BrickQuestionHidden : BrickQuestion
    {
        public static new LevelEditorObject GetLEObject()
        {
            // Sets object's properties for designing 
            return new LevelEditorObject(16, 16, 6, 5, ObjectType.OT_BrickQuestionHidden, new object[] { new object[] { new object[] { "Mush Life", (int)ObjectType.OT_GreenMushroom, "Mush Big", (int)ObjectType.OT_RedMushroom, "Coin", (int)ObjectType.OT_Bone, "Flower", (int)ObjectType.OT_Flower } }, 0 });
        }

        public static new BrickQuestionHidden SetLEObject(LevelEditorObject le)
        {
            return new BrickQuestionHidden(le.x, le.y, (ObjectType)le.ParamInt[0]);
        }

        // For when the Husky hits the hidden brick
        public override void HuskyBrickHit(object sender, EventArgs e)
        {
            base.HuskyBrickHit(sender, e);

            Collision C = LevelGenerator.CurrentLevel.Intersects(LevelGenerator.CurrentLevel.HuskyObject, this);
            if (C != null)
                if (C.Dir == CollisionDirection.CD_Down)
                {
                    if (LevelGenerator.CurrentLevel.HuskyObject.State == Husky.HuskyJumpState.Jump_Up)
                    {
                        Visible = true;
                        ProfessorExist();
                        StartMove();
                        LevelGenerator.CurrentLevel.HuskyObject.State = Husky.HuskyJumpState.Jump_Down;
                        LevelGenerator.CurrentLevel.HuskyObject.StartPosition = y;
                        LevelGenerator.CurrentLevel.HuskyObject.TimeCount = 0;
                        LevelGenerator.CurrentLevel.HuskyObject.StartVelocity = 0;
                    }

                }

        }
        public override void Draw()
        {
            if (Open)
                base.Draw();
        }
        BrickQuestionHidden(int x, int y, ObjectType hidden)
            :
            base(x, y, hidden)
        {
            Animated = false;
            Visible = false;
            OT = ObjectType.OT_BrickQuestionHidden;
        }
    }


}
