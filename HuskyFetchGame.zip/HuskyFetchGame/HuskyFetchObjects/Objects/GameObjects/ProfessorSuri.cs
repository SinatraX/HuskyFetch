﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.Utils;

namespace HuskyFetchObjects.Objects.GameObjects
{
    public class ProfessorSuri : MoveableAnimatedObject
    {
        public enum SuriState { SuriState_Walking, SuriState_Shield, SuriState_Returning, SuriState_ShieldMoving };
        public enum SuriDirection { SuriDirection_Right, SuriDirection_Left };
        public SuriState State;
        public SuriDirection Dir;
        public int ReturningTime;
        public static LevelEditorObject GetLEObject()
        {
            return new LevelEditorObject(16, 27, 10, 2, ObjectType.OT_Suri, null);
        }

        public static ProfessorSuri SetLEObject(LevelEditorObject le)
        {
            return new ProfessorSuri(le.x, le.y);
        }

        public override void Draw()
        {
            base.Draw();
        }

        // OnWalk is intended to set properties of Suri photos to make it walk
        public override void OnWalk(object sender, EventArgs e)
        {
            if (State == SuriState.SuriState_Shield && IntersectsObjects.Count == 0)
                base.OnWalk(sender, e);

            if (State == SuriState.SuriState_Walking || State == SuriState.SuriState_ShieldMoving)
            {
                if (newx <= LevelGenerator.CurrentLevel.HuskyObject.x - 160)
                {
                    if (Live)
                    {
                        Animated = false;
                        Live = false;
                        Visible = false;
                    }
                }

                base.OnWalk(sender, e);

                if (DirX > 0)
                    Dir = SuriDirection.SuriDirection_Right;
                else
                    Dir = SuriDirection.SuriDirection_Left;

                if (State != SuriState.SuriState_ShieldMoving)
                {
                    switch (Dir)
                    {
                        case SuriDirection.SuriDirection_Left:
                            {
                                OffsetIndex = 0;
                            } break;
                        case SuriDirection.SuriDirection_Right:
                            {
                                OffsetIndex = 2;
                            } break;
                    }
                }
            }
        }

        // Method Intersection contains a series of code for how
        // Suri will interact with itself, Grant, bricks, and Husky
        public override void Intersection(Collision c, GraphicObject g)
        {
            base.Intersection(c, g);

            switch (g.OT)
            {
                case ObjectType.OT_Brick:
                {
                    if (State == SuriState.SuriState_ShieldMoving)
                    {
                        if (c.Dir == CollisionDirection.CD_Left || c.Dir == CollisionDirection.CD_Right)
                            ((Brick)g).BreakBrick();
                    }
                    break;
                }
                case ObjectType.OT_Grant:
                {
                    if (State == SuriState.SuriState_ShieldMoving)
                    {
                        ((ProfessorGrant)g).HuskyGrantFall();
                    }
                    if (State == SuriState.SuriState_Walking)
                    {
                        ((ProfessorGrant)g).DirX *= -1;
                        ((ProfessorGrant)g).newx += 5 * ((ProfessorGrant)g).DirX;

                        ((ProfessorGrant)g).OnWalk(null, null);
                        DirX *= -1;
                        OnWalk(null, null);
                    }
                    if (State == SuriState.SuriState_Shield)
                    {
                        ((ProfessorGrant)g).DirX *= -1;
                        ((ProfessorGrant)g).newx += 5 * ((ProfessorGrant)g).DirX;
                        ((ProfessorGrant)g).OnWalk(null, null);
                    }
                    break;
                } 
                case ObjectType.OT_Husky:
                {
                    if (State == SuriState.SuriState_Shield && ReturningTime >= 3)
                    {
                        if (c.Dir == CollisionDirection.CD_Left)
                            DirX = -1;

                        if (c.Dir == CollisionDirection.CD_Right)
                            DirX = 1;

                        SetKoopaState(SuriState.SuriState_ShieldMoving);
                    }

                    // Size-down Husky when colliding with a koopa
                    if (State != SuriState.SuriState_Shield) // but not in shield state
                    {
                        if (!(State == SuriState.SuriState_ShieldMoving // Or that he's just set in motion
                            && (DirX == -1 && c.Dir == CollisionDirection.CD_Left) || (DirX == 1 && c.Dir == CollisionDirection.CD_Right)))
                        {
                            Husky h = (Husky)g;
                            if (c.Dir != CollisionDirection.CD_Down)
                            {
                                if (!h.Blinking)
                                {
                                    h.HuskyHandleCollision();
                                }
                            }
                        }
                    }
                    break;
                }
            } 
        }

        // OnAnimate contains animations for what Suri will look like if Husky crushes Suri
        public override void OnAnimate(object sender, EventArgs e)
        {
            base.OnAnimate(sender, e);

            if (State == SuriState.SuriState_Shield)
            {
                ReturningTime++;

                if (ReturningTime > 20)
                {
                    SetKoopaState(SuriState.SuriState_Returning);
                }
            }

            if (State == SuriState.SuriState_Returning)
            {
                ReturningTime++;
                ImageIndex = (ReturningTime % 2) * 4 + 4; //4 or 9;

                if (ReturningTime > 40)
                {
                    SetKoopaState(SuriState.SuriState_Walking);
                    ReturningTime = 0;
                }
            }
        }
        
        // SetSuriState establishes the properties of the various ProfessorSuri states.
        public void SetKoopaState(SuriState S)
        {
            State = S;
            switch (State)
            {
                case SuriState.SuriState_Walking:
                    {
                        width = 16;
                        height = 27;
                        AnimatedCount = 2;
                        newy -= 11;
                        WalkStep = 1;


                        Animated = true;
                    } break;
                case SuriState.SuriState_Shield:
                    {
                        width = 16;
                        height = 27;
                        ReturningTime = 0;
                        OffsetIndex = 0;

                        ImageIndex = 4;
                        //newy -= 11;
                        Animated = false;
                    } break;
                case SuriState.SuriState_Returning:
                    {
                        OffsetIndex = 0;
                        //Animated = false;
                    } break;
                case SuriState.SuriState_ShieldMoving:
                    {
                        width = 16;
                        height = 27;
                        //newy -= 11;

                        WalkStep = 4;
                        AnimatedCount = 4;
                        OffsetIndex = 4;
                        Animated = true;

                    } break;
            }
        }
        public ProfessorSuri(int x, int y)
            : base(ObjectType.OT_Suri)
        {
            this.x = x;
            this.y = y;
            ImageCount = 10;

            SetWidthHeight();

            SetKoopaState(SuriState.SuriState_Walking);
            Dir = SuriDirection.SuriDirection_Right;

            TimerGenerator.AddTimerEventHandler(TimerType.TT_50, this.OnWalk);
            TimerGenerator.AddTimerEventHandler(TimerType.TT_100, this.OnAnimate);

        }
    }

}
