﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using HuskyFetchObjects.Objects.BaseObjects;

namespace HuskyFetchObjects.Objects.Utils
{
    // Intended to load all objects required for the game
    public class ObjectGenerator
    {
        private static ObjectGenerator instance = null;
        public static ObjectGenerator Instance
        {
            get
            {
                if (instance == null)
                    instance = new ObjectGenerator();
                return instance;
            }
        }
        public ObjectGenerator()
        {


        }
        public static GraphicObject SetEditorObject(LevelEditorObject le)
        {

            
            Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();

            Type objType = Type.GetType("HuskyFetchObjects.Objects.GameObjects." + le.name);
            MethodInfo i = objType.GetMethod("SetLEObject");
            GraphicObject g = null;

            if (i != null)
            {
                g = (GraphicObject)i.Invoke(null, new object[] { le });
            }

            return g;
        }

        // Intended to reference the several .cs files under GameObjects
        public static LevelEditorObject GetEditorObject(string name)
        {

            
            Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();

            Type objType = Type.GetType("HuskyFetchObjects.Objects.GameObjects." + name);
            MethodInfo i = objType.GetMethod("GetLEObject");
            if (i != null)
            {
                LevelEditorObject LE = (LevelEditorObject)(i.Invoke(null, null));
                LE.name = name;
                return LE;
            }
            else
                return null;
        }
        // For listing out the game objects in static state
        // For design purposes
        public static List<LevelEditorObject> GetEditorObjects()
        {
            List<LevelEditorObject> Res = new List<LevelEditorObject>();
            Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();
            foreach (Type t in asm.GetTypes())
            {
                Type objType = Type.GetType(t.FullName);
                MethodInfo i = objType.GetMethod("GetLEObject");
                if (i != null)
                {
                    LevelEditorObject LE = (LevelEditorObject)(i.Invoke(null, null));
                    LE.name = t.Name;
                    Res.Add(LE);
                }

            }
            return Res;
        }
    }


}
