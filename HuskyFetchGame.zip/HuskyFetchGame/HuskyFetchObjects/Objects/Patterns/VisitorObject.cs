﻿using System;
using System.Collections.Generic;
using System.Text;
using HuskyFetchObjects.Objects.BaseObjects;

namespace HuskyFetchObjects.Objects.Patterns
{
    // Ref with level and graphobj
    public class VisitorObject
    {
        public virtual void Action(GraphicObject g) { }
    }
}
