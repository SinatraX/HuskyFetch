using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

using HuskyFetchObjects.Objects.Utils;
using HuskyFetchObjects.Objects.BaseObjects;
using HuskyFetchObjects.Objects.GameObjects;

namespace HuskyFetchObjects
{
    public class HuskyEditorXML
    {

        public HuskyEditorXML()
        { 
          
        }

        // SaveXML method. Referenced. Intended to save changes made in the HuskyFetchLevels file to xml.
        // Serialize
        // Saving to XML to call them when running the game (reminder: will be in .exe)
        public static void SaveXML(string filename,List<LevelEditorObject> list)
        {
            root MainObject = null;
            rootObject[] Objects = null;

            int cnt = 0;
            MainObject = new root();
            Objects = new rootObject[list.Count];

            foreach (LevelEditorObject le in list)
            {
                rootObject tmp = new rootObject();
                tmp.X = le.x;
                tmp.Y = le.y;
                tmp.OName = le.name;
                tmp.Int1 =  le.ParamInt[0];
                tmp.Int2 =  le.ParamInt[1];
                tmp.Int3 =  le.ParamInt[2];
                tmp.Bool1 = le.Parambool[0];
                tmp.Bool2 = le.Parambool[1];
                tmp.Bool3 = le.Parambool[2];

                Objects[cnt++] = tmp;

            }
            MainObject.Object = Objects;

            StreamWriter SW = new StreamWriter(filename);
            XmlSerializer xSer = new XmlSerializer(typeof(root));
            xSer.Serialize(SW, MainObject);
            SW.Close();
        }

        // Method LoadXML will be used in Form_Editor.cs to load xml file(s) to game.
        // Does not work with single .xml file. Need to figure out how to load and connect multiple files
        // Use deserialize
        // Above has been solved.
        public static List<LevelEditorObject> LoadXML(string filename)
        {
            List<LevelEditorObject> Res = new List<LevelEditorObject>();
            root MainObject = null;

            MainObject = new root();

            StreamReader SR = new StreamReader(filename);
            XmlSerializer xSer = new XmlSerializer(typeof(root));
            MainObject = (root)xSer.Deserialize(SR);
            SR.Close();

            foreach (rootObject obj in MainObject.Object)
            {
                LevelEditorObject le = ObjectGenerator.GetEditorObject(obj.OName);
                if (le != null)
                {
                    le.name = obj.OName;
                    le.x = obj.X;
                    le.y = obj.Y;
                    le.ParamInt[0] = obj.Int1;
                    le.ParamInt[1] = obj.Int2;
                    le.ParamInt[2] = obj.Int3;
                    le.Parambool[0] = obj.Bool1;
                    le.Parambool[1] = obj.Bool2;
                    le.Parambool[2] = obj.Bool3;

                    Res.Add(le);
                }
            }
            
            return Res;
        }

        // Method LoadLevelFromXML helps with switching .xml files in the event of completing the levels.
        // How this will work is based on the Load Level method in LevelManager.cs
        public static Level LoadLevelFromXML(string filename)
        {
            Level lev = new Level();

            List<LevelEditorObject> levelEditorObjects = LoadXML(filename);
            foreach (LevelEditorObject levelObject in levelEditorObjects)
            {
                GraphicObject g = ObjectGenerator.SetEditorObject(levelObject);
                if(g == null) { continue; }

                lev.AddObject(g);
                if(g.OT == ObjectType.OT_Husky)
                {
                    lev.HuskyObject = (Husky)g;
                }
            }

            return lev;
        }
    }
}
